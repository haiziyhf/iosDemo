//
//  FWResponse.m
//  Framework
//
//  Created by 吴勇 on 16/1/25.
//  Copyright © 2016年 ocphp.com. All rights reserved.
//

#import "FWResponse.h"

@implementation FWResponse

@end
