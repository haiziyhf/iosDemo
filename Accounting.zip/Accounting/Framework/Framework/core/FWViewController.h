//
//  FWViewController.h
//  Framework
//
//  Created by 吴勇 on 16/2/15.
//  Copyright © 2016年 ocphp.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIViewController+Framework.h"

@interface FWViewController : UIViewController

@prop_strong(NSString *, backBarTitle)

@end
