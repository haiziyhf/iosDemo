//
//  FWAction.h
//  Framework
//
//  Created by wuyong on 16/2/16.
//  Copyright © 2016年 ocphp.com. All rights reserved.
//

#import <Foundation/Foundation.h>

//动作基类，目的是重构优化控制器代码
@interface FWViewAction : NSObject

@end
