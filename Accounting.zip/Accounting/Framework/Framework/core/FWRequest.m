//
//  FWNetwork.m
//  Framework
//
//  Created by 吴勇 on 16/1/25.
//  Copyright © 2016年 ocphp.com. All rights reserved.
//

#import "FWRequest.h"

@implementation FWRequest

@def_singleton(FWRequest)

@end
