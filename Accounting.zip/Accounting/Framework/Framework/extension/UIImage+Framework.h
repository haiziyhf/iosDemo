//
//  UIImage+Framework.h
//  Framework
//
//  Created by 吴勇 on 16/1/30.
//  Copyright © 2016年 ocphp.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (Framework)

+ (instancetype)imageFromView:(UIView *)view;

@end
