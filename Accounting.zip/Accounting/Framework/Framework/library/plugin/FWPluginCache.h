//
//  FWPluginCache.h
//  Framework
//
//  Created by wuyong on 16/1/26.
//  Copyright © 2016年 ocphp.com. All rights reserved.
//

#import <Foundation/Foundation.h>

//定义插件池默认保存名称
#define FWPluginCacheName @"FWPluginCache"

@protocol FWPluginCache <FWProtocolRegistry>

TODO("set key value expire")

@end
