//
//  FWPluginDialogMBProgressHUD.h
//  Framework
//
//  Created by wuyong on 16/1/25.
//  Copyright © 2016年 ocphp.com. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FWPluginDialog.h"

//默认弹出框
@interface FWPluginDialogDefault : NSObject<FWPluginDialog>

@end
