//
//  AppDelegate.h
//  Accounting
//
//  Created by 杨海锋 on 16/2/23.
//  Copyright © 2016年 haizi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NavigationController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate,REFrostedViewControllerDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

