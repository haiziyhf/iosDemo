//
//  AppView.m
//  LttMember
//
//  Created by wuyong on 15/6/10.
//  Copyright (c) 2015年 Gilbert. All rights reserved.
//

#import "AppView.h"

@implementation BaseView (App)

- (void) customView
{
    //修正闪烁
    self.backgroundColor = COLOR_MAIN_BG;
}

@end

@implementation AppView

@end
