//
//  AppTableView.h
//  LttMember
//
//  Created by wuyong on 15/6/10.
//  Copyright (c) 2015年 Gilbert. All rights reserved.
//

#import "AppView.h"
#import "BaseTableView.h"

@interface BaseTableView (App)

- (void) customTableView;

@end

@interface AppTableView : BaseTableView

@end
