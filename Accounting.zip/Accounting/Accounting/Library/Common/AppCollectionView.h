//
//  AppCollectionView.h
//  LttMember
//
//  Created by wuyong on 15/9/28.
//  Copyright © 2015年 Gilbert. All rights reserved.
//

#import "AppView.h"
#import "BaseCollectionView.h"

@interface BaseCollectionView (App)

- (void) customCollectionView;

@end

@interface AppCollectionView : BaseCollectionView

@end
